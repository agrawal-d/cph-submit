# cph-submit

![ICON](icon-48.png)

**Pre-alpha release**

Browser add on that enables codeforces submit for C++ 17 with [Competitive Programming Helper](https://github.com/agrawal-d/cph)

Tested with Firefox. Load the Zip file in `about:debugging`.
